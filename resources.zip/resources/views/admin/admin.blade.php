@extends('layouts.app')

@section('content')
<my-header></my-header>
<router-view></router-view>
@endsection
