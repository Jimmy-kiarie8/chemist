@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero fuga perferendis, accusamus suscipit provident tempore fugit officia at, commodi esse autem minima quidem excepturi nemo necessitatibus quasi dolore alias officiis.                    
You are logged in!
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
