<template>
<section class="bg-title-page p-t-50 p-b-40 flex-col-c-m" style="">
    <h2 class="l-text2 t-center" style="color: #000;">
        Healthwise <span style="color: rgba(2, 234, 0, 0.58);">Pharmacy</span>
    </h2>
    <p class="m-text13 t-center">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. 
    </p>
</section>
</template>

<script>
export default {

}
</script>

<style scoped>
.bg-title-page{ 
    background-image: url(/healthwise/img/8.jpg) !important;
    background-attachment: fixed !important;
}
</style>
