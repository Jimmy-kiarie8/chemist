<template>
<v-app id="inspire"  v-scroll="onScroll">
  <header class="header2">
    <!-- Header desktop -->
    <div class="wrap_header fixed-header2 trans-0-4">
      <!-- Logo -->
      <router-link to="/" class="logo">
        <img src="/healthwise/logo.png" alt="IMG-LOGO">
      </router-link>

      <!-- Menu -->
      <div class="wrap_menu">
        <nav class="menu">
          <ul class="main_menu">
            <li>
              <router-link to="/">Home</router-link>
              <!-- <a href="index.html">Home</a> -->
              <!-- <ul class="sub_menu">
                <li>
                  <a href="index.html">Homepage V1</a>
                </li>
                <li>
                  <a href="home-02.html">Homepage V2</a>
                </li>
                <li>
                  <a href="home-03.html">Homepage V3</a>
                </li>
              </ul> -->
            </li>

            <li>
              <router-link to="/shop">Shop</router-link>
            </li>

            <li>
              <router-link to="/cartHome">Cart</router-link>
            </li>

            <li>
              <router-link to="/about">About Us</router-link>
            </li>

            <!-- <li>
                        <a href="cart.html">Features</a>
                    </li>

                    <li>
                        <a href="blog.html">Blog</a>
                    </li>

                    <li>
                        <a href="about.html">About</a>
                    </li>

                    <li>
                        <a href="contact.html">Contact</a>
            </li>-->
          </ul>
        </nav>
      </div>

      <!-- Header Icon -->
      <div class="header-icons">
        <a href="#" class="header-wrapicon1 dis-block">
          <img src="/healthwise/icons/icon-header-01.png" class="header-icon1" alt="ICON">
        </a>
        
        <span class="linedivide1"></span>

        <div class="header-wrapicon2">
          <img
            src="/healthwise/icons/icon-header-02.png"
            class="header-icon1 js-show-header-dropdown"
            alt="ICON"
          >
          <span class="header-icons-noti">{{ cartItems.length }}</span>

          <!-- Header cart noti -->
          <myCart></myCart>
        </div>
      </div>
    </div>

    <!-- <div class="flex-c-m size22 bg0 s-text21 pos-relative">
        20% off everything!
        <a href="product.html" class="s-text22 hov6 p-l-5">

Shop Now

</a>

        <button class="flex-c-m pos2 size23 colorwhite eff3 trans-0-4 btn-romove-top-noti">

<i class="fa fa-remove fs-13" aria-hidden="true"></i>

</button>
    </div>-->
    <div class="container-menu-header-v2 p-t-26">
      <div class="topbar2">
        <div class="topbar-social">
          <a href="#" class="topbar-social-item fa fa-facebook"></a>
          <a href="#" class="topbar-social-item fa fa-instagram"></a>
          <a href="#" class="topbar-social-item fa fa-pinterest-p"></a>
          <a href="#" class="topbar-social-item fa fa-snapchat-ghost"></a>
          <a href="#" class="topbar-social-item fa fa-youtube-play"></a>
        </div>

        <!-- Logo2 -->
        <a href="index.html" class="logo2">
          <img src="/healthwise/logo.png" alt="IMG-LOGO">
        </a>

        <div class="topbar-child2">
          <span class="topbar-email">healthwise@example.com</span>

          <div class="topbar-language rs1-select2">
            <select class="selection-1" name="time">
              <option>KSH</option>
            </select>
          </div>

          <!--  -->
          <a href="#" class="header-wrapicon1 dis-block m-l-30">
            <img src="/healthwise/icons/icon-header-01.png" class="header-icon1" alt="ICON">
          </a>
          
          <span class="linedivide1"></span>

          <div class="header-wrapicon2 m-r-13">
            <img
              src="/healthwise/icons/icon-header-02.png"
              class="header-icon1 js-show-header-dropdown"
              alt="ICON"
            >
            <span class="header-icons-noti">{{ cartItems.length }}</span>

            <!-- Header cart noti -->
            <myCart></myCart>
          </div>
        </div>
      </div>

      <div class="wrap_header">
        <!-- Menu -->
        <div class="wrap_menu">
          <nav class="menu">
            <ul class="main_menu">
              <li>
              <router-link to="/">Home</router-link>
              <!-- <a href="index.html">Home</a> -->
              <!-- <ul class="sub_menu">
                <li>
                  <a href="index.html">Homepage V1</a>
                </li>
                <li>
                  <a href="home-02.html">Homepage V2</a>
                </li>
                <li>
                  <a href="home-03.html">Homepage V3</a>
                </li>
              </ul> -->
            </li>

            <li>
              <router-link to="/shop">Shop</router-link>
            </li>

            <li>
              <router-link to="/cartHome">Cart</router-link>
            </li>

            <li>
              <router-link to="/about">About Us</router-link>
            </li>
            </ul>
          </nav>
        </div>

        <!-- Header Icon -->
        <div class="header-icons"></div>
      </div>
    </div>

    <!-- Header Mobile -->
    <div class="wrap_header_mobile">
      <!-- Logo moblie -->
      <a href="index.html" class="logo-mobile">
        <img src="/healthwise/logo.png" alt="IMG-LOGO" style="max-width: 100px;">
      </a>

      <!-- Button show menu -->
      <div class="btn-show-menu">
        <!-- Header Icon mobile -->
        <div class="header-icons-mobile">
          <a href="#" class="header-wrapicon1 dis-block">
            <img src="/healthwise/icons/icon-header-01.png" class="header-icon1" alt="ICON">
          </a>
          
          <span class="linedivide2"></span>

          <div class="header-wrapicon2">
            <img
              src="/healthwise/icons/icon-header-02.png"
              class="header-icon1 js-show-header-dropdown"
              alt="ICON"
            >
            <span class="header-icons-noti">{{ cartItems.length }}</span>

            <!-- Header cart noti -->
            <myCart></myCart>
          </div>
        </div>

        <div class="btn-show-menu-mobile hamburger hamburger--squeeze">
          <span class="hamburger-box">
            <span class="hamburger-inner"></span>
          </span>
        </div>
      </div>
    </div>

    <!-- Menu Mobile -->
    <div class="wrap-side-menu">
      <nav class="side-menu">
        <ul class="main-menu">
          <li class="item-topbar-mobile p-l-20 p-t-8 p-b-8">
            <span class="topbar-child1">Free shipping for standard order over Ksh1000</span>
          </li>

          <li class="item-topbar-mobile p-l-20 p-t-8 p-b-8">
            <div class="topbar-child2-mobile">
              <span class="topbar-email">healthwise@example.com</span>

              <div class="topbar-language rs1-select2">
                <select class="selection-1" name="time">
                  <option>KSH</option>
                </select>
              </div>
            </div>
          </li>

          <li class="item-topbar-mobile p-l-10">
            <div class="topbar-social-mobile">
              <a href="#" class="topbar-social-item fa fa-facebook"></a>
              <a href="#" class="topbar-social-item fa fa-instagram"></a>
              <a href="#" class="topbar-social-item fa fa-pinterest-p"></a>
              <a href="#" class="topbar-social-item fa fa-snapchat-ghost"></a>
              <a href="#" class="topbar-social-item fa fa-youtube-play"></a>
            </div>
          </li>

          <li>
              <router-link to="/" style="color: #333">Home</router-link>
              <!-- <a href="index.html">Home</a> -->
              <!-- <ul class="sub_menu">
                <li>
                  <a href="index.html">Homepage V1</a>
                </li>
                <li>
                  <a href="home-02.html">Homepage V2</a>
                </li>
                <li>
                  <a href="home-03.html">Homepage V3</a>
                </li>
              </ul> -->
            </li>

            <li>
              <router-link to="/shop" style="color: #333">Shop</router-link>
            </li>

            <li>
              <router-link to="/cartHome" style="color: #333">Cart</router-link>
            </li>
        </ul>
      </nav>
    </div>
  </header>
  <v-fab-transition v-if="offsetTop >= 400">
      <v-btn color="pink" dark fab fixed bottom right ref="button" @click="$vuetify.goTo(target)">
        <v-icon>keyboard_arrow_up</v-icon>
      </v-btn>
    </v-fab-transition>
    <v-snackbar :timeout="timeout" :bottom="y === 'bottom'" :color="Scolor" :left="x === 'left'" v-model="snackbar">
        {{ message }}
        <v-icon dark right>check_circle</v-icon>
    </v-snackbar>
    <!-- <Show></Show> -->
  </v-app>
</template>

<script>
import myCart from "../cart/Cartvue";
// import Show from "../home/Show";
import myShop from "../Shop/Shop";
import CartHome from "../cart/CartHome";
export default {
  // router,
  components: {
    // Show,
    myShop,
    CartHome,
    myCart
  },
  data() {
    return {
      cartItems: [],
      categories: [],
      menus: [],
      drawer: true,
      right: null,
      snackbar: false,
      y: "bottom",
      x: "left",
      Allusers: [],
      Scolor: "",
      timeout: 5000,
      offsetTop: 0,
      message: "Success"
    };
  },
  methods: {
    
    onScroll(e) {
      this.offsetTop = window.pageYOffset || document.documentElement.scrollTop;
      if (this.offsetTop > 200) {
        eventBus.$emit("changeTra");
      } else {
        eventBus.$emit("changeOpr");
      }
    },
    addToCart(cart) {
      console.log(cart);
      eventBus.$emit("loadingRequest");
      axios
        .post(`/cart/${cart}`)
        .then(response => {
          eventBus.$emit("cartEvent", response.data);
          // this.cart = response.data
          // this.message = "added";
          eventBus.$emit("alertRequest");
          // this.snackbar = true;
        })
        .catch(error => {
          this.loading = false;
          this.errors = error.response.data.errors;
        });
    },
    categoryPro(data) {
      // console.log(data)
      eventBus.$emit("filterEvent", data.id);

      // router.go('')
      // this.$router.push(`/filter/${data.id}`)
    },
    unfilter() {
      this.loadingalert();
      eventBus.$emit("unfilterEvent");
    },
    getCart() {
      axios.get("/getCart").then(response => {
        this.cartItems = response.data;
        eventBus.$emit("cartEvent", response.data);
      });
    },

    showalert() {
      this.message = "success";
      this.Scolor = "black";
      this.snackbar = true;
    },

    loadingalert() {
      this.message = "Loading...";
      this.Scolor = "black";
      this.y = "top";
      this.x = "right";
      this.snackbar = true;
    }
  },
  mounted() {
    this.getCart();
    axios
      .get("/categories")
      .then(response => {
        this.categories = response.data;
      })
      .catch(error => {
        // this.loading = false;
        this.errors = error.response.data.errors;
      });

    axios
      .get("/menus")
      .then(response => {
        this.menus = response.data;
      })
      .catch(error => {
        // this.loading = false;
        this.errors = error.response.data.errors;
      });
  },
  created() {
    eventBus.$on("addCartEvent", data => {
      this.addToCart(data);
    });
    eventBus.$on("cartEvent", data => {
      this.cartItems = data;
    });
    eventBus.$on("alertRequest", data => {
      this.showalert();
    });
    eventBus.$on("loadingRequest", data => {
      this.loadingalert();
    });

    this.timer = window.setInterval(() => {
      this.getCart();
      // eventBus.$emit("cartEvent", response.data);
    }, 60000);
  },
  
  computed: {
    target() {
      const value = this[this.type];
      return Number(value);
    }
  }
};
</script>

<style scoped>
/* .router-link-active {
      color: #333 !important;
} */
.router-link-exact-active {
      color: #e65540 !important;
}
</style>
